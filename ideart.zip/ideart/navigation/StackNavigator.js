import React from "react";
import { createStackNavigator } from "@react-navigation/stack";
import TabNavigator from "./TabNavigator";


const Stack = createStackNavigator();

const StackNavigator = () => {
  return (
    <Stack.Navigator
      initialRouteName="Inicio"
      screenOptions={{
        headerShown: false
      }}
    >
      <Stack.Screen name="Inicio" component={TabNavigator} />
      <Stack.Screen name="PantallaDeHistoria" component={StoryScreen} />
    </Stack.Navigator>
  );
};

export default StackNavigator;
