import React, { Component } from "react";
import {View,StyleSheet,SafeAreaView,Platform,StatusBar,Image,TextInput,Alert,TouchableOpacity,
  Text} from "react-native";

const appIcon = require("../assets/logo.png");

export default class LoginScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: "",
      password: "",
      fontsLoaded: false,
      userSignedIn: false
    };
  }

  signIn = async (email, password) => {
    firebase
      .auth()
      .signInWithEmailAndPassword(email, password)
      .then(() => {
        this.props.navigation.replace("Panel");
      })
      .catch(error => {
        Alert.alert(error.message);
      });
  };


  render() {
      const { email, password } = this.state;
      return (
        <View style={styles.container}>
          <SafeAreaView style={styles.droidSafeArea} />

          <Text style={styles.appTitleText}>IdeArt</Text>
          <Image source={appIcon} style={styles.appIcon} />

          <TextInput
            style={styles.textinput}
            onChangeText={text => this.setState({ email: text })}
            placeholder={"Ingresar correo electrónico"}
            placeholderTextColor={"#FFFFFF"}
            autoFocus
          />
          <TextInput
            style={[styles.textinput, { marginTop: 40 }]}
            onChangeText={text => this.setState({ password: text })}
            placeholder={"Ingresar contraseña"}
            placeholderTextColor={"#FFFFFF"}
            secureTextEntry
          />
          <TouchableOpacity
            style={[styles.button, { marginTop: 50 }]}
            onPress={() => this.signIn(email, password)}
          >
            <Text style={styles.buttonText}>Inicio de sesión</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => this.props.navigation.navigate("PaginaRegistro")}
          >
            <Text style={styles.buttonTextNewUser}>¿Usuario nuevo?</Text>
          </TouchableOpacity>
        </View>
      );
    }
  }


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "purple",
    alignItems: "center",
    justifyContent: "center"
  },
  droidSafeArea: {
    
  },
  appIcon: {
    width:100,
    height:100   
  },
  appTitleText: {
    fontSize:15,
    fontFamily:"verdana",
    color: "white",
    textAlign: "center",
  },
  textinput: {
    borderColor: "skyblue",
    color: "#FFFFFF",
    backgroundColor: "skyblue",
    
  },
  button: {
    flexDirection: "row",
    justifyContent: "space-evenly",
    alignItems: "center",
    backgroundColor: "white",
    borderRadius:30,
    borderColor:"red"
  },
  buttonText: {
   fontSize:15,
  },
  buttonTextNewUser: {
    
    color: "#FFFFFF",
    textDecorationLine: 'underline'
  }
});

