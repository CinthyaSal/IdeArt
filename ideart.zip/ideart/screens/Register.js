import React, { Component } from "react";
import {
  View,
  StyleSheet,
  SafeAreaView,
  Platform,
  StatusBar,
  Image,
  TextInput,
  Alert, 
  TouchableOpacity,
  Text
} from "react-native";

import * as Font from "expo-font";

import * as SplashScreen from 'expo-splash-screen';
SplashScreen.preventAutoHideAsync();


const appIcon = require("../assets/logo.png");

export default class RegisterScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      first_name:"",
      last_name:"",
      email: "",
      password: "",
      confirmPassword: "",
      fontsLoaded: false
    };
  }

  componentDidMount() {
   // this._loadFontsAsync();
  }
 
 registerUser = (email, password,confirmPassword,first_name,last_name) => {
  if(password==confirmPassword){
    firebase
      .auth()
      .createUserWithEmailAndPassword(email, password)
      .then((userCredential) => {
        Alert.alert("User registered!!");
        console.log(userCredential.user.uid)
        this.props.navigation.replace("Login");
        firebase.database().ref("/users/" + userCredential.user.uid)
                .set({
                  email: userCredential.user.email,
                  first_name: first_name,
                  last_name: last_name,
                  current_theme: "dark"
                })
      })
      .catch(error => {
        Alert.alert(error.message);
      });
    }else{
      Alert.alert("¡Las contraseñas no coinciden!");
    }
  };
  

  render() {
      const { email, password, confirmPassword, first_name, last_name } = this.state;
      
      return (
        <View style={styles.container}>
          <SafeAreaView style={styles.droidSafeArea} />

            <Text style={styles.appTitleText}>Registrarse</Text>
           
            <TextInput
              style={styles.textinput}
              onChangeText={text => this.setState({ first_name: text })}
              placeholder={"Nombre"}
              placeholderTextColor={"#FFFFFF"}
    
            />
            <TextInput
              style={styles.textinput}
              onChangeText={text => this.setState({ last_name: text })}
              placeholder={"Apellido"}
              placeholderTextColor={"#FFFFFF"}
        
            />
            <TextInput
              style={styles.textinput}
              onChangeText={text => this.setState({ email: text })}
              placeholder={"Ingresar correo electrónico"}
              placeholderTextColor={"#FFFFFF"}
  
            />
            <TextInput
              style={styles.textinput}
              onChangeText={text => this.setState({ password: text })}
              placeholder={"Ingresar contraseña"}
              placeholderTextColor={"#FFFFFF"}
              secureTextEntry
            />
            <TextInput
              style={styles.textinput}
              onChangeText={text => this.setState({ confirmPassword: text })}
              placeholder={"Ingresar nuevamente la contraseña"}
              placeholderTextColor={"#FFFFFF"}
              secureTextEntry
            />
            <TouchableOpacity
              style={[styles.button, { marginTop: 20 }]}
              onPress={() => this.registerUser(email, password, confirmPassword,first_name,last_name)}
            >
              <Text style={styles.buttonText}>Registrarse</Text>
            </TouchableOpacity>    
            <TouchableOpacity
              onPress={()=>this.props.navigation.replace("InicioSesion")}
            >
              <Text style={styles.buttonTextNewUser}>¿Iniciar sesión?</Text>
            </TouchableOpacity>         
        </View>
      );
    }
  }


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#15193c",
    alignItems:"center",
    justifyContent:"center"
  },
  droidSafeArea: {
   
  },
 
  appTitleText: {
    color: "white",
    textAlign: "center",
   
  },
  textinput: {
    borderColor: "#FFFFFF",
    borderWidth:2,
    borderRadius:20,
    width:200,
    height:35,
    color: "#FFFFFF",
    backgroundColor: "purple",
    marginTop:10,
  },
  button: {
    flexDirection: "row",
    justifyContent: "space-evenly",
    alignItems: "center",
    borderRadius:30,
    backgroundColor: "white",
    width:80,
    height:30,
   
  },
  buttonText: {
   
    color: "red",
   
  },
  buttonTextNewUser: {
   
    color: "#FFFFFF",
    textDecorationLine: 'underline'
  }
});
