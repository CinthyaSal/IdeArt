const firebaseConfig = {
  apiKey: "AIzaSyCBfWV2OYc6T62gCmT2-uQLxFSNMDYUTbE",
  authDomain: "pineart-f5f88.firebaseapp.com",
  projectId: "pineart-f5f88",
  storageBucket: "pineart-f5f88.appspot.com",
  messagingSenderId: "261085691059",
  appId: "1:261085691059:web:238a4986e48a43cda644c6"
};